<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pt_BR">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <source>MainWindow</source>
        <translation>Janela Principal</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="35"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;h1 align=&quot;center&quot; style=&quot; margin-top:18px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:xx-large; font-weight:600;&quot;&gt;Qpdf Tools&lt;/span&gt;&lt;/h1&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;h1 align=&quot;center&quot; style=&quot; margin-top:18px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:xx-large; font-weight:600;&quot;&gt;Qpdf Tools&lt;/span&gt;&lt;/h1&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="42"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;h2 align=&quot;center&quot; style=&quot; margin-top:16px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:x-large; font-weight:600;&quot;&gt;Tools for manage PDFs&lt;/span&gt;&lt;/h2&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;h2 align=&quot;center&quot; style=&quot; margin-top:16px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:x-large; font-weight:600;&quot;&gt;Ferramentas para Gerenciar PDFs&lt;/span&gt;&lt;/h2&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="65"/>
        <source>Compress a PDF file</source>
        <translation>Comprimir um arquivo PDF</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="81"/>
        <source>Split a PDF file</source>
        <translation>Dividir um arquivo PDF</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="94"/>
        <source>Rotate a PDF file</source>
        <translation>Rotacionar um arquivo PDF</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="107"/>
        <source>Merge PDF files</source>
        <translation>Juntar arquivos PDF</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="124"/>
        <location filename="../src/mainwindow.ui" line="243"/>
        <location filename="../src/mainwindow.ui" line="437"/>
        <location filename="../src/mainwindow.ui" line="553"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="127"/>
        <location filename="../src/mainwindow.ui" line="246"/>
        <location filename="../src/mainwindow.ui" line="440"/>
        <location filename="../src/mainwindow.ui" line="556"/>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="151"/>
        <location filename="../src/mainwindow.ui" line="270"/>
        <location filename="../src/mainwindow.ui" line="580"/>
        <source>Select PDF</source>
        <translation>Selecionar PDF</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="163"/>
        <source>Select the compression mode:</source>
        <translation>Selecione o modo de compressão:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="169"/>
        <source>Super low resolution (Screen Optimized)</source>
        <translation>Super baixa resolução (Otimizado para tela)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="176"/>
        <source>Low resolution (For Ebooks)</source>
        <translation>Baixa resolução (Para Ebooks)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="183"/>
        <source>Normal resolution (For printing)</source>
        <translation>Resolução normal (Para Impressão)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="190"/>
        <source>High resolution</source>
        <translation>Alta resolução</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="215"/>
        <source>Compress PDF</source>
        <translation>Comprimir PDF</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="303"/>
        <source>Split by range</source>
        <translation>Dividir por intervalo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="316"/>
        <source>Extract all pages</source>
        <translation>Extrair todas as páginas</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="342"/>
        <source>From page:</source>
        <translation>Da página:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="360"/>
        <source>To page:</source>
        <translation>Para página:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="409"/>
        <source>Split PDF</source>
        <translation>Dividir PDF</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="525"/>
        <source>Merge PDFs</source>
        <translation>Juntar PDFs</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="663"/>
        <source>Left</source>
        <translation>Esquerda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="683"/>
        <source>Right</source>
        <translation>Direita</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="737"/>
        <source>Rotate PDF</source>
        <translation>Rotacionar PDF</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="63"/>
        <source>Click to add a PDF file</source>
        <translation>Clique para adicionar um arquivo PDF</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="67"/>
        <source>Click to remove a PDF file</source>
        <translation>Clique para remover um arquivo PDF</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="71"/>
        <location filename="../src/mainwindow.cpp" line="75"/>
        <source>Click to change the merge order</source>
        <translation>Clique para mudar a ordem dos PDFs</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="86"/>
        <source>click to rotate the PDF 90 degrees to the left</source>
        <translation>Clique para rotacioanr PDF em 90° para esquerda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="90"/>
        <source>click to rotate the PDF 90 degrees to the right</source>
        <translation>Clique para rotacioanr PDF em 90° para direita</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="231"/>
        <location filename="../src/mainwindow.cpp" line="417"/>
        <source>Select the PDF file</source>
        <translation>Selecione o arquivo PDF</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="137"/>
        <location filename="../src/mainwindow.cpp" line="152"/>
        <location filename="../src/mainwindow.cpp" line="203"/>
        <location filename="../src/mainwindow.cpp" line="285"/>
        <location filename="../src/mainwindow.cpp" line="359"/>
        <source>Warning</source>
        <translation>Atenção</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="137"/>
        <location filename="../src/mainwindow.cpp" line="203"/>
        <location filename="../src/mainwindow.cpp" line="359"/>
        <source>You need to select a valide PDF file</source>
        <translation>Você precisa selecionar um arquivo PDF válido</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="152"/>
        <source>You need to select a compression mode</source>
        <translation>Você precisa selecionar um modo de compressão</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="414"/>
        <source>Save file</source>
        <translation>Salvar Arquivo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="210"/>
        <source>Select Output Folder</source>
        <translation>Selecione a pasta de saída</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="285"/>
        <source>You need to add two or more files to be able to merge them</source>
        <translation>Você precisa adcionar dois ou mais arquivos para poder unir-los</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="389"/>
        <source>Processing...</source>
        <translation>Processando...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="402"/>
        <source>ERROR</source>
        <translation>ERRO</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="403"/>
        <source>Failed</source>
        <translation>Falhou</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="405"/>
        <source>Success!</source>
        <translation>Sucesso!</translation>
    </message>
</context>
</TS>
